
# IA conectada à Deriv com token real
import websocket

TOKEN = "RNsW7x2gkyS7Fl2"
print("IA Nêmesis conectada com token:", TOKEN)
